<?php
session_start();
include 'config.php';
if(isset($_POST['adminsubmit']))
{
$adminusername=$_POST['adminusername']; // Get username
$adminpassword=$_POST['adminpassword']; // get password
$_SESSION['adminusername']=$adminusername;
$ret=mysqli_query($con,"SELECT * FROM adminlogin WHERE userName='$adminusername'  and password='$adminpassword'");
$num=mysqli_fetch_array($ret);
$admingroup=$num['admingroup'];
$_SESSION['admingroup']=$admingroup;

// if user inputs match if condition will runn

if($num>0)
{

if($admingroup=="all")
{
$_SESSION['msg']="Username and password accepted";
$extra="admin/index.php";
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
else
{
$_SESSION['msg']="Username and password accepted";
$extra="admin/index_limited.php";
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}

}

if(empty($num))
{
$_SESSION['msg']="Invalid username or password";
}

}
?>

<!DOCTYPE html>
<html >
<head>
<meta charset="UTF-8">
<title>User login and tracking in PHP using PHP OOPs Concept</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<form name="admin" method="post" >
  <header>Admin Login Panel</header>
  <p style="color:red;"><?php echo $_SESSION['msg'];?><?php echo $_SESSION['msg']="";?></p>
  <p style="padding-left:1%;"><b>Plese login with Admin userid and password</b></p>

  <label>Admin ID<span>*</span></label>
  <input name="adminusername" type="text" value="" required />
  <label>Password<span>*</span></label>
  <input name="adminpassword" type="password" value="" required />
  <button type="submit" name="adminsubmit">Submit</button>

  <p style="padding-left:39%;">Back to Login Page ? <a href="index.php">Sign in</a></p> 
  <p style="padding-left:15%;"><font color=blue><font size="2">This site is maintained by TCS Platform Linux, for any queries, email to Site Admin <a href="emailtoadmin.php">Click Here</a></font></font></p>
</form>
</body>
</html>

