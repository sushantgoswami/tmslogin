<?php
session_start();
include 'config.php';

if(isset($_POST['resumelogin']))
{
$resumeoption=$_POST['resumeoption'];
$reason=$_POST['reason'];

if($resumeoption=="Resume_extend")
{
$extra="welcome.php";
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}

if($resumeoption=="Logout_plus_nine_hours")
{
$robotlogout="robotlogout";
$_SESSION['robotlogout']=$robotlogout;
$extra="logout.php";
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}

}
?>



<!DOCTYPE html>
<html >
<head>
<meta charset="UTF-8">
<title>User login and tracking in PHP using PHP OOPs Concept</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style2.css">
</head>
<body>

<form name="login" method="post" >
  <header>Login to Timesheet management system</header>
  <p style="color:red;"><?php echo $_SESSION['msg'];?><?php echo $_SESSION['msg']="";?></p>
  <p style="padding-left:1%;"><b>Previous Login is detected which is greater than 9 hours, please choose options below</b></p>

  <label>Select Option<span>*</span></label>
  <select id="resumeoption" name="resumeoption">
  <option value="Resume_extend">I have to work more than 9 hours, Resume and continue to Old Session.</option>
  <option value="Logout_plus_nine_hours">May be I forgot to Logout, Logout and set previous shift as 9 hours.</option>
  </select>

  <label>Select Reason for Re Login<span>*</span></label>
  <select id="reason" name="reason">
  <option value="computer_restart">My Computer restarts</option>
  <option value="forgot_to_logout">I Forgot to Logout</option>
  <option value="unknown_reason">I remeber I logged out, but somehow it is not reflecting</option>
  </select>

  <button type="submit" name="resumelogin">Submit</button>

  <p style="padding-left:37%;"><b>Join us as a member? </b><a href="register.php">Sign UP</a></p>
  <p style="padding-left:37%;"><b>Login to Admin Panel </b><a href="admin.php">Click Here</a></p>
  <p style="padding-left:37%;"><b>Reset your password </b><a href="passwordreset.php">Click Here</a></p>
  <p style="padding-left:15%;"><font color=blue><font size="2">This site is maintained by TCS Platform Linux, for any queries, email to Site Admin <a href="emailtoadmin.php">Click Here</a></font></font></p>

</form>


  </body>
</html>

