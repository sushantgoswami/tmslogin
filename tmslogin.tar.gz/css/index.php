<script language="javascript">
document.location="../index.php";
</script>
